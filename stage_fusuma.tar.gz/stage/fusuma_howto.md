# 襖ステージ 手順書

ロボットが襖のつまみを横に押して襖を開けると、後ろの Hello World 看板が見える、というステージです。

## 配置（真上から見た図）

```
            見る人（正面から撮影）
                  ↓
   ======[ 襖 ]======>   ← 襖は右（+y）にスライドして開く
         [看板]              DOOR_X = 0.165（16.5cm）
                             SIGN_X = 0.13（13cm）
          (ロボット)          根元 = 0
```

- 看板（Hello World）は今までと同じもので、固定されています
- 襖は看板の手前（見る人の側）にあり、看板を隠しています
- 襖は**レールに沿って左右にしか動きません**。倒れたり回ったりしません。動ける範囲は 0〜12cm で、開ききると止まります
- 襖の**上の端の左側（ロボットから見て右側）**に、茶色の「つまみ」が出っ張っています。アームの手先でこれを横に押します
- ※ ロボットから見ると、見る人とは左右が逆になります

## 1. 準備（初回だけ）

### サーバの SSH で、ファイルを展開
```bash
cd ~/pai_ros2 && tar xzf stage_fusuma.tar.gz
ls ~/pai_ros2/stage
```
`fusuma.sdf`、`spawn_fusuma.sh`、`reset_fusuma.sh` が増えていれば OK です（今までの看板などのファイルはそのまま残ります）。

## 2. 起動と配置

```bash
ros2 launch crane_plus_gazebo crane_plus_with_table.launch.py   # シミュレータ
/workspace/stage/spawn_fusuma.sh                                  # 別ターミナルで、看板と襖を出す
```

### 最初に確認すること
1. **襖が立っているか**：テーブルの上に、襖がまっすぐ立っていて倒れないか
2. **柄の向き**：正面から見て、柄（上が和紙と金の粒、下が波模様、丸い引手）が逆さまになっていないか
3. **看板が隠れているか**：正面から見て、Hello World が襖で隠れているか
4. **襖が動くか**：teleop でアームを動かし、つまみを横から押して、襖がスライドするか

## 3. 位置の調整

`spawn_fusuma.sh` と `reset_fusuma.sh` の先頭にある数字を変えます（サーバの SSH なら `nano ~/pai_ros2/stage/spawn_fusuma.sh` で編集できます）。

- アームが**つまみに届かない** → `DOOR_X` を小さく（ロボットに近く）する。例: 0.155
- 襖と看板がぶつかる・近すぎる → 看板の `SIGN_X` を小さくする。例: 0.12
- **`DOOR_X` を変えたら、`reset_fusuma.sh` の `DOOR_X` も同じ値にする**こと

変更したら、シミュレータを起動し直して `spawn_fusuma.sh` を実行します。

## 4. テレオペの練習（記録はまだしない）

### 動かし方のイメージ
1. **joint1（土台の回転）で、手先をつまみの横（ロボットから見て、つまみの手前側）に向ける**
2. joint2・joint3・joint4 で手を伸ばし、手先をつまみの高さ（テーブルから 10cm くらい）に合わせる
   - つまみの真上から下ろすと、つまみに乗ってしまうので、**先に横にずらしてから下ろす**のがコツ
3. **joint1 を回して、つまみを横に押す** → 襖がスライドして開く
4. Hello World が見えたら止める

- joint1 の W/S のどちらが左右どちらに回るかは、最初に試して確認してください
- 横から押す・上から見るなど、視点を回してすき間を確認しながらやると、ずれにくいです

### やり直し
teleop で `X`（直立に戻す）→ `/workspace/stage/reset_fusuma.sh`（襖を閉じた状態に戻す）

### 手順書を作る
目隠しのときと同じく、**キーと回数を決めて、記録なしで 5 回連続で成功する**まで練習します。
つまみに手先がかする工程は、余裕を持ったクリック数にします。

```
（例）
① joint1 を選択 → ○ を ○ 回
② joint2 を選択 → ○ を ○ 回
③ joint3 を選択 → ○ を ○ 回
④ joint1 を選択 → ○ を ○ 回（つまみを押して襖を開ける）
```

## 5. 記録（新しいフォルダ hello_fusuma に）

```bash
ros2 bag record -a -o ~/dataset/rosbags/hello_fusuma/ep0    # ep1, ep2, ... と増やす
```

1 回ごとに: `X` で直立 → `reset_fusuma.sh` → 記録開始 → **すぐ**操作 → 開いたら**すぐ** `Ctrl+C`
失敗した回は `rm -r ~/dataset/rosbags/hello_fusuma/epN` で消して撮り直し。目安は 20 回。

## 6. 設定ファイルの書き換え（~/pai_training/configs）

`hello_world_v2` を `hello_fusuma` に置き換えます。

- `conversion_config.yaml`
  - `bag_dir: "/home/ubuntu/dataset/rosbags/hello_fusuma"`
  - `output_dir: "/home/ubuntu/dataset/lerobot_dataset/crane_plus_hello_fusuma"`
- `crane_features.py`
  - `repo_id = "crane_plus_hello_fusuma"`
  - `root = "/home/ubuntu/dataset/lerobot_dataset/crane_plus_hello_fusuma"`
  - `task_name = "hello_fusuma"`
- `train_config.yaml`
  - `dataset_root: "/home/ubuntu/dataset/lerobot_dataset/crane_plus_hello_fusuma"`
  - `repo_id: "crane_plus_hello_fusuma"`
  - `output_directory: "/home/ubuntu/checkpoints/train/crane_plus_hello_fusuma_act"`
  - training_steps 3000 / batch_size 8 / log_freq 50 は前回と同じで OK

## 7. 変換・学習・再現

```bash
cd ~/pai_training
pixi run convert
WANDB_MODE=disabled pixi run train      # シミュレータは止めておく
```

再現（シミュレータを起動 → `spawn_fusuma.sh` → **teleop は閉じてから**）:
```bash
pixi run infer --model-path /home/ubuntu/checkpoints/train/crane_plus_hello_fusuma_act
```

## うまくいかないとき

| 症状 | 対処 |
|---|---|
| 襖が倒れる・テーブルを突き抜けて落ちる | レールの設定が効いていない可能性があります。起動時のターミナルのエラーと一緒に相談 |
| 柄が逆さま・鏡文字のように見える | 相談してください（画像の向きを直します） |
| 押しても襖が動かない | つまみではなく襖の本体に当たっていないか、横から視点を回して確認 |
| `reset_fusuma.sh` で襖が出てこない | `sleep 2` を `sleep 4` に増やす |
| infer でアームが動かない | teleop が起動したままになっていないか確認 |
