#!/bin/bash
# 襖を閉じた状態に戻す（一度消して、出し直す）
# 使い方: /workspace/stage/reset_fusuma.sh
# ※ 先に teleop の X でアームを直立に戻してから実行すること
#
# ▼ spawn_fusuma.sh と同じ値にそろえること
DOOR_X=0.165
# ▲

DIR=/workspace/stage
TABLE_Z=1.015
DOOR_Z=$(awk "BEGIN{print $TABLE_Z + 0.048}")

ign service -s /world/default/remove \
  --reqtype ignition.msgs.Entity --reptype ignition.msgs.Boolean --timeout 2000 \
  --req 'name: "fusuma" type: MODEL'
sleep 2
ros2 run ros_gz_sim create -file $DIR/fusuma.sdf -name fusuma -x $DOOR_X -y 0 -z $DOOR_Z
