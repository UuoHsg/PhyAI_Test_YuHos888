#!/bin/bash
# Hello World 看板と襖をシミュレータに出現させる
# 使い方: /workspace/stage/spawn_fusuma.sh
#
# ▼位置の調整はここ（単位はメートル。ロボットの根元からの距離）
SIGN_X=0.13     # Hello World 看板（固定）
DOOR_X=0.165    # 襖（看板より見る人の側に置く。看板と 3cm 以上離す）
# ▲

DIR=/workspace/stage
TABLE_Z=1.015
SIGN_Z=$(awk "BEGIN{print $TABLE_Z + 0.025 + 0.001}")
DOOR_Z=$(awk "BEGIN{print $TABLE_Z + 0.048}")   # 襖の底がテーブルから 3mm 浮く高さ

ros2 run ros_gz_sim create -file $DIR/hello_sign.sdf -name hello_sign -x $SIGN_X -y 0 -z $SIGN_Z
ros2 run ros_gz_sim create -file $DIR/fusuma.sdf     -name fusuma     -x $DOOR_X -y 0 -z $DOOR_Z
